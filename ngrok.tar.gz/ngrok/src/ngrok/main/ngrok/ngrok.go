package main

import (
	"ngrok/client"
)

func main() {
	client.Main()
}
